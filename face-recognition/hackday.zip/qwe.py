import json

from kafka import KafkaProducer

producer = KafkaProducer(bootstrap_servers=['172.21.120.37:9092'],
                         value_serializer=lambda m: json.dumps(m).encode('ascii'))
# producer.DEFAULT_CONFIG['bootstrap_servers'] = ['172.21.120.37:9092']
# def send_to_kafka(id_face, similarity, face_photo, video_frame):
#     _, face_enc = cv2.imencode('.jpg', face_photo)
#     _, video_enc = cv2.imencode('.jpg', video_frame)
#     jpg_as_text_face = base64.b64encode(face_enc)
#     jpg_as_text_video = base64.b64encode(video_enc)
for i in range(0, 2):
    data = {'id': '1', 'face_photo': '2'}
    res = producer.send('server.face-rec4', value=data)

producer.flush()
producer.close()
